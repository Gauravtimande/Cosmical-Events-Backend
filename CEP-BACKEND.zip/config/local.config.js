export const config = {
	host: "http://localhost",
	port: 5000,
	baseUrl: "",
	db: {
	  host: "localhost",
	  port: 3306,
	  username: "Gaurav",
	  database: "Cosmical-Events",
	  password: "Gaurav@123"
	}
  };
config.baseUrl = `${config.host}:${config.port}/`;
  